from django.urls import path

from . import views

app_name = "catalog"

urlpatterns = [
    path("", views.monster_list, name="monster_list"),
]

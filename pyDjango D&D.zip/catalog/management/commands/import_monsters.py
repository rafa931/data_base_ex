import time

import requests
from django.core.management.base import BaseCommand

from catalog.models import Monster

BASE = "https://www.dnd5eapi.co"


class Command(BaseCommand):
    help = "Import D&D monsters from the D&D 5e API"

    def handle(self, *args, **options):
        listing = requests.get(f"{BASE}/api/2014/monsters", timeout=10).json()

        for item in listing["results"]:
            data = requests.get(f"{BASE}{item['url']}", timeout=10).json()

            Monster.objects.update_or_create(
                index=data["index"],
                defaults={
                    "name": data["name"],
                    "size": data["size"],
                    "monster_type": data["type"],
                    "challenge_rating": data["challenge_rating"],
                    "hit_points": data["hit_points"],
                    "image_url": f"{BASE}{data['image']}" if data.get("image") else "",
                },
            )
            self.stdout.write(f"Saved {data['name']}")
            time.sleep(0.1)  # be polite to the free API

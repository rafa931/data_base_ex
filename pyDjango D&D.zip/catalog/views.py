from django.shortcuts import render

from .models import Monster


def monster_list(request):
    query = request.GET.get("q", "").strip()
    monsters = Monster.objects.order_by("name")
    if query:
        monsters = monsters.filter(name__icontains=query)
    return render(
        request,
        "catalog/monster_list.html",
        {"monsters": monsters, "query": query},
    )

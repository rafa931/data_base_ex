from django.db import models

# Create your models here.


class Monster(models.Model):
    index = models.CharField(max_length=100, unique=True)
    name = models.CharField(max_length=100)
    size = models.CharField(max_length=20)
    monster_type = models.CharField(max_length=50)
    challenge_rating = models.FloatField()
    hit_points = models.IntegerField()
    image_url = models.URLField(blank=True)

    def __str__(self):
        return self.name

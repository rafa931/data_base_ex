import sqlite3
from contextlib import closing
from pathlib import Path


def create_db_from_schema(db_path: str, schema_file: str) -> None:
    sql = Path(schema_file).read_text(encoding="utf-8")
    with closing(sqlite3.connect(db_path)) as conn:
        conn.executescript(sql)
        conn.commit()


def run_sql_file(db_path: str, sql_file: str) -> None:
    sql = Path(sql_file).read_text(encoding="utf-8")
    with closing(sqlite3.connect(db_path)) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(sql)
        conn.commit()


def split_statements(sql: str) -> list[str]:
    statements, buffer = [], ""
    for line in sql.splitlines(keepends=True):
        buffer += line
        if sqlite3.complete_statement(buffer):
            statements.append(buffer.strip())
            buffer = ""
    return statements


def query_sql_file(db_path: str, sql_file: str) -> None:
    sql = Path(sql_file).read_text(encoding="utf-8")
    with closing(sqlite3.connect(db_path)) as conn:
        for statement in split_statements(sql):
            cursor = conn.execute(statement)
            if cursor.description:
                print([col[0] for col in cursor.description])
                for row in cursor.fetchall():
                    print(row)
        conn.commit()


def split_statements(sql: str) -> list[str]:
    statements, buffer = [], ""
    for line in sql.splitlines(keepends=True):
        buffer += line
        if sqlite3.complete_statement(buffer):
            statements.append(buffer.strip())
            buffer = ""
    return statements


BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "database.db"

if __name__ == "__main__":
    DB_PATH.unlink(missing_ok=True)
    create_db_from_schema(DB_PATH, BASE_DIR / "schema.sql")
    run_sql_file(DB_PATH, BASE_DIR / "data.sql")
    query_sql_file(DB_PATH, BASE_DIR / "queries.sql")

INSERT  INTO director (
  name,
  age
)
VALUES                ('Christopher Nolan', 55),
                      ('Greta Gerwig', 41);

INSERT  INTO actor (
  name,
  age
)
VALUES             ('Leonardo DiCaprio', 50),
                   ('Margot Robbie', 35),
                   ('Cillian Murphy', 49);

INSERT  INTO movie (
  title,
  year
)
VALUES             ('Inception', 2010),
                   ('Barbie', 2023),
                   ('Oppenheimer', 2023);

INSERT  INTO movie_director (
  movie_id,
  director_id
)
VALUES                      (1, 1),
                            (2, 2),
                            (3, 1);

INSERT  INTO movie_actor (
  movie_id,
  actor_id
)
VALUES                   (1, 1),
                         (2, 2),
                         (3, 3);

INSERT  INTO rating (
  movie_id,
  rating
)
VALUES              (1, 8.8),
                    (2, 6.9),
                    (3, 8.5);

UPDATE director
SET    age = 56
WHERE  name = 'Christopher Nolan';

UPDATE actor
SET    age = 51
WHERE  name = 'Leonardo DiCaprio';
-- join: movies with their director
-- join: actors in each movie
-- nested: movies rated above the average rating
-- nested: actors older than the average actor age

